# I-N-F-I-N-I-T-Y-CALCULATOR
A Program you can run using VS Code that you press ENTER to generate numbers AND THE BEST THING IS THAT IT COUNTS UNTIL I N F I N I T Y !
