﻿using System;

namespace infinity_counter
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 1; i <= 9999999; i++)//LOOP!
            
            {
                Console.WriteLine("HOLD OR PRESS ENTER TO COUNT UNTIL I N F I N I T Y."); //INSTRUCTIONS
                Console.ReadKey();        //WAIT AND DON'T CLOSE WINDOW
                Console.WriteLine(i+1);  
                Console.ReadKey();
                if (int 1 = 1; i<= 9999999;)
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("YOU REACHED I N F I N I T Y !");
            }
            
        }
    }
}
